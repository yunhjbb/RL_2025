import numpy as np


class DotDealReward():
    
    def __init__(self, config):
        pass

    def get_reward(self, model, data, step, additional_data = None):
        return 1

