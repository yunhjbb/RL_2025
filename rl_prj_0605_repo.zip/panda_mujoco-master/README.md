# Panda Robot in MuJoCo
This repository has been superseded by two alternative projects:

* [mujoco_menagerie](https://github.com/google-deepmind/mujoco_menagerie) includes a pure `MuJoCo` model of the Panda
* [dm_robotics_panda](https://github.com/JeanElsner/dm_robotics_panda) Panda model and tools for reinforcement learning in `dm_robotics`
